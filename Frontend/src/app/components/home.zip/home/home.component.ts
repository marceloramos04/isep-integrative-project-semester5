import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '@auth0/auth0-angular';
import { Router } from '@angular/router'; // Para navegar entre as páginas

@Component({
  selector: 'app-home',
  standalone: false,
  // imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  implements OnInit{
  title = 'Frontend';
  isLoggedIn: boolean = false;


  constructor(public auth: AuthService, private router: Router) {
      auth.isAuthenticated$.subscribe(isAuthenticaded => {
      this.isLoggedIn = isAuthenticaded;
     });
  }

  ngOnInit(): void {
    this.auth.isAuthenticated$.subscribe(isAuthenticaded => {
      if (isAuthenticaded) {
        this.router.navigate(['/app-admin-view'])
      }
    })
  }

  login() {
    this.auth.loginWithRedirect();
    this.isLoggedIn = true;
  }

  logout() {
    // this.auth.logout({ returnTo: window.location.origin }); 
    // this.isLoggedIn = false;
  }
  
  navigateToAdminView() {
    this.router.navigate(['/admin-view']); // Usando router para navegar para a tela de admin
  }

  navigateToDoctorView() {
    this.router.navigate(['/doctor-view']); // Usando router para navegar para a tela de doctor
  }
}
